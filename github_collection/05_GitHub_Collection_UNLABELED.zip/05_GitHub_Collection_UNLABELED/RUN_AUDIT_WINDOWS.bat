@echo off
cd /d "%~dp0"
py -3.11 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements-base.txt
.venv\Scripts\python.exe audit_github.py
pause
