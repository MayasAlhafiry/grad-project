"""Effort metrics. All predictions and actuals are working person-hours >0."""
import numpy as np
import pandas as pd

def effort_metrics(y,p):
    y=np.asarray(y,dtype=float);p=np.asarray(p,dtype=float)
    if not len(y) or not np.all(np.isfinite(y)) or not np.all(y>0) or not np.all(np.isfinite(p)):
        raise ValueError('Need finite positive actual hours and finite predictions')
    p=np.maximum(0.0,p);ae=np.abs(y-p);rel=ae/y
    truth=y>24;alert=p>24;tp=int((truth&alert).sum());fp=int((~truth&alert).sum());fn=int((truth&~alert).sum())
    return {'samples':int(len(y)),'MAE_hours':float(ae.mean()),'PRED25_percent':float(100*(rel<=.25).mean()),'MdMRE_percent':float(100*np.median(rel)),'over24_actual':int(truth.sum()),'over24_flagged':int(alert.sum()),'over24_true_positive':tp,'over24_false_positive':fp,'over24_missed':fn,'over24_precision_percent':None if tp+fp==0 else float(100*tp/(tp+fp)),'over24_recall_percent':None if tp+fn==0 else float(100*tp/(tp+fn)),'long_tasks_MAE_hours':None if not truth.any() else float(ae[truth].mean())}

def save_results(data,pred,outdir,prefix):
    from pathlib import Path
    import json
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    predictions=data[['issue_key','project_key','text','actual_hours']].copy()
    predictions['predicted_hours']=np.maximum(0,pred)
    predictions['absolute_error_hours']=np.abs(predictions['actual_hours']-predictions['predicted_hours'])
    predictions['PRED25_pass']=predictions['absolute_error_hours']/predictions['actual_hours']<=.25
    predictions['actual_over24']=predictions['actual_hours']>24
    predictions['predicted_over24']=predictions['predicted_hours']>24
    predictions.to_csv(out/f'{prefix}_predictions.csv',index=False)
    metrics=effort_metrics(data['actual_hours'],pred)
    (out/f'{prefix}_metrics.json').write_text(json.dumps(metrics,indent=2),encoding='utf-8')
    return metrics
