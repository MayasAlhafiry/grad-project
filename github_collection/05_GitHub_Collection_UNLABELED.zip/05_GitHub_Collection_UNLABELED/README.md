# GitHub tasks - prospective Agile-hours collection

8 real linked GitHub issues, with topic/domain/language hints. No actual worked-hour labels and no verified developer experience, so DO NOT train/test a supervised hour predictor on them. Collect verified start-of-task text and team worklogs prospectively.

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-base.txt
.\.venv\Scripts\python.exe audit_github.py
```

See docs/DATASET_GUIDE.pdf.
