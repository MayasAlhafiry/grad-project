"""Collection metadata audit only. No fabricated effort labels."""
from pathlib import Path
import pandas as pd,json
HERE=Path(__file__).resolve().parent

def main():
    d=pd.read_csv(HERE/'data'/'source'/'SmartFlow_GitHub_New_Task_Collection_UNLABELED.csv');l=pd.to_numeric(d['actual_hours'],errors='coerce')
    out=HERE/'results';out.mkdir(exist_ok=True)
    report={'real_issue_rows':len(d),'nonempty_issue_urls':int(d['source_url'].notna().sum()),'rows_with_valid_positive_hours':int(l.gt(0).sum()),'usable_supervised_training_rows':0,'note':'Issue descriptions and source links do not establish working-hour ground truth. Domain, languages, phase, experience are unverified unless collected with provenance.'}
    (out/'COLLECTION_AUDIT.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
